package GamePanels;

import Structures.Game;
import Structures.Piece;

public class PiecePanel {
    Piece piece;

    public PiecePanel(Piece p){
        piece = p;
    }
}
