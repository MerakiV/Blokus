package GamePanels;

import java.awt.*;

public interface GamePlay {

    public void update();

    public void draw(Graphics2D g);
}
