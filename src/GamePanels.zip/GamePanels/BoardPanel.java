package GamePanels;

import Structures.Board;
import Structures.Color;

import javax.imageio.ImageIO;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.IOException;

public class BoardPanel implements GamePlay{
    Board board;
    Image image;
    Point position;
    private Dimension size;

    public BoardPanel(Board board){
        this.board = board;
        position = new Point();
        try{
            this.image = ImageIO.read(getClass().getResourceAsStream("images/board.png"));
            size = new Dimension(this.image.getWidth(null), this.image.getHeight(null));
        } catch (IOException e){
            e.printStackTrace();
        }
    }
    @Override
    public void update(){

    }
    @Override
    public void draw(Graphics2D g){
        Graphics2D graphics = (Graphics2D)g.create();
        graphics.drawImage(this.image, (int)position.getX(), (int)position.getY(), null, null);
        for (int i = 0; i < Board.size; i++){
            for (int j = 0; j < Board.size; j++){
                try{
                    Color color = this.board.getColor(i, j);
                    if (color != Color.WHITE) {
                        String path = "";
                        switch (color) {
                            case BLUE:
                                path = "tiles/BlueBloc.png";
                                break;
                            case GREEN:
                                path = "tiles/GreenBloc.png";
                                break;
                            case RED:
                                path = "tiles/RedBloc.png";
                                break;
                            case YELLOW:
                                path = "tiles/YellowBloc.png";
                                break;
                        }
                        Image tile = null;
                        try {
                            tile = ImageIO.read(getClass().getResource(path));
                        } catch (IOException e) {
                            e.printStackTrace();
                        }
                        int tileH = tile.getHeight(null);
                        int tileW =tile.getWidth(null);
                        graphics.drawImage(tile, i*tileW, j*tileH, tileW, tileH, null);
                    }
                } catch (IndexOutOfBoundsException e){
                    e.printStackTrace();
                }
            }
        }
    graphics.dispose();
    }

    public Board getBoard(){
        return this.board;
    }

    public Dimension getSize(){
        return size;
    }
}
